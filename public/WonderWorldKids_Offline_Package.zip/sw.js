/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "fbeade0080e6d90acbf3681065f92932"
  }, {
    "url": "pwa-512x512.png",
    "revision": "fbeade0080e6d90acbf3681065f92932"
  }, {
    "url": "pwa-192x192.png",
    "revision": "fbeade0080e6d90acbf3681065f92932"
  }, {
    "url": "logo.png",
    "revision": "fbeade0080e6d90acbf3681065f92932"
  }, {
    "url": "index.html",
    "revision": "814e09eb81ae8cedf5d55c8c631be3e4"
  }, {
    "url": "icon.svg",
    "revision": "5622eacf69725310fda138035ce44d5a"
  }, {
    "url": "favicon.png",
    "revision": "fbeade0080e6d90acbf3681065f92932"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "fbeade0080e6d90acbf3681065f92932"
  }, {
    "url": "fonts/fonts.css",
    "revision": "59cc92d50238ff901ff7cc3920b74cfa"
  }, {
    "url": "fonts/font_9_6xKtdSZaM9iE8KbpRA_hJFQNcOM.woff2",
    "revision": "5eaa7de506d26633f78d8f1e793e077e"
  }, {
    "url": "fonts/font_8_X7n64b87HvSqjb_WIi2yDCRwoQ_k7367_DWu89U.woff2",
    "revision": "9591efe1be62434d2d107e2b19702029"
  }, {
    "url": "fonts/font_7_X7n64b87HvSqjb_WIi2yDCRwoQ_k7367_DWg89XyHw.woff2",
    "revision": "d3c5911bfd9a22a841b4fc6c1d3847d1"
  }, {
    "url": "fonts/font_6_X7n64b87HvSqjb_WIi2yDCRwoQ_k7367_DWs89XyHw.woff2",
    "revision": "e3b7076aee49a198b28246237611749c"
  }, {
    "url": "fonts/font_5_X7n64b87HvSqjb_WIi2yDCRwoQ_k7367_DWu89U.woff2",
    "revision": "9591efe1be62434d2d107e2b19702029"
  }, {
    "url": "fonts/font_4_X7n64b87HvSqjb_WIi2yDCRwoQ_k7367_DWg89XyHw.woff2",
    "revision": "d3c5911bfd9a22a841b4fc6c1d3847d1"
  }, {
    "url": "fonts/font_3_X7n64b87HvSqjb_WIi2yDCRwoQ_k7367_DWs89XyHw.woff2",
    "revision": "e3b7076aee49a198b28246237611749c"
  }, {
    "url": "fonts/font_2_X7n64b87HvSqjb_WIi2yDCRwoQ_k7367_DWu89U.woff2",
    "revision": "9591efe1be62434d2d107e2b19702029"
  }, {
    "url": "fonts/font_1_X7n64b87HvSqjb_WIi2yDCRwoQ_k7367_DWg89XyHw.woff2",
    "revision": "d3c5911bfd9a22a841b4fc6c1d3847d1"
  }, {
    "url": "fonts/font_14_6xKtdSZaM9iE8KbpRA_hK1QN.woff2",
    "revision": "9d503278216c2225184a236c64e0924b"
  }, {
    "url": "fonts/font_13_6xKtdSZaM9iE8KbpRA_hJVQNcOM.woff2",
    "revision": "7ee01e648403b775b222bba928ecaf81"
  }, {
    "url": "fonts/font_12_6xKtdSZaM9iE8KbpRA_hJFQNcOM.woff2",
    "revision": "5eaa7de506d26633f78d8f1e793e077e"
  }, {
    "url": "fonts/font_11_6xKtdSZaM9iE8KbpRA_hK1QN.woff2",
    "revision": "9d503278216c2225184a236c64e0924b"
  }, {
    "url": "fonts/font_10_6xKtdSZaM9iE8KbpRA_hJVQNcOM.woff2",
    "revision": "7ee01e648403b775b222bba928ecaf81"
  }, {
    "url": "fonts/font_0_X7n64b87HvSqjb_WIi2yDCRwoQ_k7367_DWs89XyHw.woff2",
    "revision": "e3b7076aee49a198b28246237611749c"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-D2fu23y8.js",
    "revision": null
  }, {
    "url": "assets/index-BUO5Ymha.css",
    "revision": null
  }, {
    "url": "assets/aistudio/Wonder_World_Kids_Adventure_Badge_ba215e1b.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_20261105-001323_4b0b4154.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_20261029-231620_4cc16840.png",
    "revision": null
  }, {
    "url": "assets/aistudio/1793523005352_538c3f3a.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "fbeade0080e6d90acbf3681065f92932"
  }, {
    "url": "favicon.png",
    "revision": "fbeade0080e6d90acbf3681065f92932"
  }, {
    "url": "pwa-192x192.png",
    "revision": "fbeade0080e6d90acbf3681065f92932"
  }, {
    "url": "pwa-512x512.png",
    "revision": "fbeade0080e6d90acbf3681065f92932"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "fbeade0080e6d90acbf3681065f92932"
  }, {
    "url": "assets/aistudio/Wonder_World_Kids_Adventure_Badge_ba215e1b.png",
    "revision": "fbeade0080e6d90acbf3681065f92932"
  }, {
    "url": "manifest.webmanifest",
    "revision": "ea2f19b157463071c43606f4cc789c7f"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("/index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
