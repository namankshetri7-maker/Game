@echo off
setlocal
cd /d "%~dp0"
title Wonder World Kids - Super Quest Launcher

echo ========================================================
echo   Wonder World Kids - Super Quest (Offline Mode)
echo ========================================================
echo   Checking local runtime components...

:: 1. Check if Node.js is installed
where node >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo   Found Node.js runtime. Launching server...
    node launcher.cjs
    goto :end
)

:: 2. Fall back to Windows built-in PowerShell server (zero extra installs needed)
where powershell.exe >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo   Using Windows native PowerShell launcher...
    powershell.exe -ExecutionPolicy Bypass -NoProfile -File "%~dp0start-server.ps1"
    goto :end
)

echo.
echo ========================================================
echo   ERROR: Neither Node.js nor PowerShell was detected!
echo   To play Wonder World Kids on Windows:
echo   1. Make sure Windows PowerShell is enabled, OR
echo   2. Install Node.js from https://nodejs.org
echo ========================================================
pause

:end
