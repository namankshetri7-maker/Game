@echo off
title WonderWorld Kids Learning - Offline Suite
echo ========================================================
echo   WonderWorld Kids Learning Suite - Offline Mode
echo   Starting 100%% offline browser launcher...
echo ========================================================
start "" "%~dp0index.html"
