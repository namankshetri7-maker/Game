================================================================================
  WONDER WORLD KIDS: SUPER QUEST — 100% OFFLINE FAMILY EDITION
================================================================================
Commercial Model: One-Time Purchase ($9 USD)
Privacy: Zero Ads • Zero Tracking • Zero Cloud Accounts Required
Offline: 100% Offline Procedural Sound • Local Device Storage
Age Group: 3–10 Years (Adaptive Curriculum Across 5 Worlds)

================================================================================
1. WINDOWS PC SETUP (Windows 10, 11, 8, 7)
================================================================================
Step 1: Extract this ZIP file completely into a folder on your computer
        (e.g., C:\Games\WonderWorldKids). Do not run directly from inside the ZIP!
Step 2: Double-click "Play on Windows.bat".
Step 3: A friendly command window will start the local game server and
        automatically open your default web browser (Edge, Chrome, or Firefox).
Step 4: Keep the command window open while your child plays. When they are
        finished, simply close the window to shut down the game.

Notice on ES Modules: Modern educational web games use JavaScript ES Modules.
Running via "Play on Windows.bat" ensures the game loads with proper security
headers without browser file:// protocol restrictions.

================================================================================
2. MAC SETUP (macOS Sonoma, Ventura, Monterey, Big Sur)
================================================================================
Step 1: Extract this ZIP file into your Applications or Documents folder.
Step 2: Double-click "Play on Mac.command".
        (Tip: The first time you run it, macOS Gatekeeper may ask for permission.
        Right-click "Play on Mac.command" and select "Open", then click "Open").
Step 3: Safari or your default browser will launch at http://localhost:8080.
Step 4: Keep the Terminal window open while playing, and close it when done.

================================================================================
3. IPAD & IPHONE SETUP (Progressive Web App - PWA)
================================================================================
Wonder World Kids runs as an installable Progressive Web App (PWA) on iOS:
Step 1: Open the Wonder World Kids web address in Safari on your iPad or iPhone.
Step 2: Tap the "Share" button in Safari (the square with an arrow pointing up).
Step 3: Scroll down the share menu and tap "Add to Home Screen".
Step 4: Tap "Add" in the top-right corner.
Step 5: Tap the Wonder World Kids icon on your home screen!
        It opens in full-screen standalone mode with all 45 games precached
        for offline play. You can disconnect Wi-Fi or turn on Airplane Mode
        and play anytime!

Notice: A Progressive Web App (PWA) runs locally in standalone display mode
using cached assets. It is not an App Store native binary.

================================================================================
4. ANDROID TABLET & PHONE SETUP (Progressive Web App - PWA)
================================================================================
Step 1: Open the Wonder World Kids web address in Chrome or Edge on your device.
Step 2: Tap the in-app "Install App" button in the header, OR tap the browser's
        three-dot menu (⋮) in the top-right corner.
Step 3: Select "Install app" or "Add to Home screen".
Step 4: Confirm installation. The Wonder World Kids icon will appear on your
        home screen and app drawer.
Step 5: Launch the app from your home screen. All assets and sound synthesizers
        are cached locally for offline play!

================================================================================
5. FAMILY PRIVACY & COPPA GUARANTEE
================================================================================
- Zero Analytics: No Google Analytics, Facebook Pixel, or tracking SDKs.
- Zero Advertising: No banner ads, interstitial videos, or sponsored content.
- Zero Cloud Logins: No email addresses, phone numbers, or passwords collected.
- Local Storage: Player profiles, stars, and sticker albums remain strictly on
  this device.
- Backup & Transfer: Parents can export a family backup JSON file in the Parent
  Dashboard to transfer progress to another family tablet or computer.

Thank you for supporting independent, ad-free educational software for kids!
