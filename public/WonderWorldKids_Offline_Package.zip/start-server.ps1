# Wonder World Kids - Built-in Windows PowerShell Web Server
# Uses .NET HttpListener. Requires no Node.js or Python installation!
$ErrorActionPreference = 'SilentlyContinue'
$Port = 8080
$Root = $PSScriptRoot

# Try to find an available port
for ($i = 0; $i -lt 10; $i++) {
    $TestPort = $Port + $i
    try {
        $Listener = New-Object System.Net.HttpListener
        $Listener.Prefixes.Add("http://localhost:$TestPort/")
        $Listener.Start()
        $Port = $TestPort
        break
    } catch {
        $Listener = $null
    }
}

if (-not $Listener -or -not $Listener.IsListening) {
    Write-Host "Error: Unable to bind to local HTTP port." -ForegroundColor Red
    Write-Host "Please close other applications and try again."
    pause
    exit 1
}

$Url = "http://localhost:$Port/"
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  Wonder World Kids - Super Quest (Offline Suite)" -ForegroundColor Yellow
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  Starting local server at $Url" -ForegroundColor Green
Write-Host "  Keep this window open while playing!" -ForegroundColor White
Write-Host "  Close this window when finished." -ForegroundColor Gray
Write-Host "========================================================" -ForegroundColor Cyan

# Open default browser
Start-Process $Url

# Mime types hashtable
$Mimes = @{
    ".html" = "text/html; charset=utf-8";
    ".js"   = "application/javascript; charset=utf-8";
    ".mjs"  = "application/javascript; charset=utf-8";
    ".css"  = "text/css; charset=utf-8";
    ".json" = "application/json; charset=utf-8";
    ".png"  = "image/png";
    ".svg"  = "image/svg+xml";
    ".ico"  = "image/x-icon";
    ".woff2"= "font/woff2";
    ".woff" = "font/woff";
    ".ttf"  = "font/ttf"
}

try {
    while ($Listener.IsListening) {
        $Context = $Listener.GetContext()
        $Request = $Context.Request
        $Response = $Context.Response

        $ReqPath = $Request.Url.LocalPath.TrimStart('/')
        if ([string]::IsNullOrEmpty($ReqPath) -or $ReqPath -eq '/') {
            $ReqPath = 'index.html'
        }

        $FilePath = Join-Path $Root $ReqPath
        if (-not (Test-Path $FilePath -PathType Leaf)) {
            $FilePath = Join-Path $Root 'index.html'
        }

        $Ext = [System.IO.Path]::GetExtension($FilePath).ToLower()
        $ContentType = "application/octet-stream"
        if ($Mimes.ContainsKey($Ext)) {
            $ContentType = $Mimes[$Ext]
        }

        try {
            $Bytes = [System.IO.File]::ReadAllBytes($FilePath)
            $Response.ContentType = $ContentType
            $Response.ContentLength64 = $Bytes.Length
            $Response.AddHeader("Cache-Control", "no-cache")
            $Response.OutputStream.Write($Bytes, 0, $Bytes.Length)
        } catch {
            $Response.StatusCode = 500
        } finally {
            $Response.Close()
        }
    }
} finally {
    if ($Listener) { $Listener.Stop(); $Listener.Close() }
}
