#!/bin/bash
cd "$(dirname "$0")"
echo "========================================================"
echo "  Wonder World Kids - Super Quest (Offline Mode)"
echo "========================================================"
echo "  Checking Mac runtime components..."

# 1. Try Node.js if available
if command -v node >/dev/null 2>&1; then
    echo "  Starting via Node.js runtime..."
    node launcher.cjs
    exit 0
fi

# 2. Try Python 3 (standard on macOS)
if command -v python3 >/dev/null 2>&1; then
    echo "  Starting via macOS Python 3..."
    python3 launcher.py
    exit 0
fi

# 3. Try legacy Python 2
if command -v python >/dev/null 2>&1; then
    echo "  Starting via macOS Python..."
    python launcher.py
    exit 0
fi

echo ""
echo "========================================================"
echo "  Neither Node.js nor Python3 was found on your Mac."
echo "  To play Wonder World Kids:"
echo "  1. Install Node.js (https://nodejs.org) OR"
echo "  2. Open Terminal and run 'xcode-select --install' for Python."
echo "========================================================"
read -p "Press Enter to exit..."
