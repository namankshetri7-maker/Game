#!/bin/bash
cd "$(dirname "$0")"
echo "========================================================"
echo "  WonderWorld Kids Learning Suite - Offline Mode"
echo "  Launching WonderWorld Kids in your default browser..."
echo "========================================================"
open index.html
