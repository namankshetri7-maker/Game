#!/usr/bin/env python3
"""
Wonder World Kids - Local Python Server Launcher
Compatible with Python 3.x
"""
import os
import sys
import webbrowser
from http.server import HTTPServer, SimpleHTTPRequestHandler

PORT = 8080
os.chdir(os.path.dirname(os.path.abspath(__file__)))

class KidsHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

    def guess_type(self, path):
        if path.endswith('.js') or path.endswith('.mjs'):
            return 'application/javascript; charset=utf-8'
        if path.endswith('.woff2'):
            return 'font/woff2'
        return super().guess_type(path)

    def do_GET(self):
        # Fallback to index.html for SPA routes
        path = self.translate_path(self.path)
        if not os.path.exists(path) or os.path.isdir(path):
            self.path = '/index.html'
        return super().do_GET()

for test_port in range(PORT, PORT + 20):
    try:
        httpd = HTTPServer(('127.0.0.1', test_port), KidsHandler)
        PORT = test_port
        break
    except OSError:
        continue

url = f"http://localhost:{PORT}/"
print("========================================================")
print("  Wonder World Kids - Super Quest (Offline Mode)")
print("========================================================")
print(f"  Local Server RUNNING at: {url}")
print("  Keep this terminal window open while playing.")
print("  Press Ctrl+C to close the game when finished.")
print("========================================================")

webbrowser.open(url)
try:
    httpd.serve_forever()
except KeyboardInterrupt:
    print("\nShutting down server. Goodbye!")
    httpd.server_close()
